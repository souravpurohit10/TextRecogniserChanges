

import UIKit
import Vision
import VisionKit

var billDetailsArray = [String]()
class ViewController: UIViewController {
    
    //Variable to store the processed image
    var image: UIImage?
    //Outlet of text view that will show result of processed image
    @IBOutlet private weak var textView: UITextView!
    //Outlet of activity indicator shown while the image processes
    @IBOutlet private weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var scanImageIcon: UIImageView!
    
    @IBOutlet weak var scanImageLabel: UILabel!
    
    @IBOutlet weak var cameraImage: UIImageView!
    
    @IBOutlet weak var choosePhotoButton: UIButton!
    
    @IBOutlet weak var loadingBillsLabel: UILabel!
    
    // Vision requests to be performed on each image processed.
    private var requests = [VNRequest]()
    
    // Dispatch queue to perform Vision requests.
    private let textRecognitionWorkQueue = DispatchQueue(label: "TextRecognitionQueue",
                                                         qos: .userInitiated, attributes: [], autoreleaseFrequency: .workItem)
    //Variable to store the text of the processed image
    private var resultingText = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        updateProcessedText()
    }
    
    /*
     Method name: updateProcessedText
     Description: this method recognises the text and updates the observation result
     */
    private func updateProcessedText() {
        let textRecognitionRequest = VNRecognizeTextRequest { (request, error) in
            guard let observations = request.results as? [VNRecognizedTextObservation] else {
                print("The observations are of an unexpected type.")
                return
            }
            // Concatenate the recognised text from all the observations.
            let maximumCandidates = 1
            for observation in observations {
                guard let candidate = observation.topCandidates(maximumCandidates).first else { continue }
                do {
                    let detector = try NSDataDetector(types: NSTextCheckingAllTypes)
                    let range = NSRange(candidate.string.startIndex..<candidate.string.endIndex, in: candidate.string)
                    detector.enumerateMatches(in: candidate.string,
                                              options: [],
                                              range: range) { (match, flags, _) in
                                                guard let match = match else {
                                                    return
                                                }
                                                
                                                switch match.resultType {
                                                case .date:
                                                    self.resultingText += "Bill Date: \(candidate.string)" + "\n"
                                                case .phoneNumber:
                                                    self.resultingText += "Phone Number: \(candidate.string)" + "\n"
                                                case .address:
                                                    self.resultingText += "Address: \(candidate.string)" + "\n"
                                                default:
                                                    return
                                                }
                    }
                } catch {
                    print("handle error")
                }
            }
        }
        // specify the recognition level
        textRecognitionRequest.recognitionLevel = .accurate
        self.requests = [textRecognitionRequest]
    }
    
    /*
     Method name: choosePhotoAction
     Description: This action is calle don  the click of the choose photo button. Allows user to choose photo from the photo library
     */
    @IBAction func choosePhotoAction(_ sender: Any) {
        presentPhotoPicker(type: .photoLibrary)
        self.hideUnhideControls(boolValue: true)
    }
    
    /*
     Method name: presentPhotoPicker
     Description: This method presents the photo library
     */
    fileprivate func presentPhotoPicker(type: UIImagePickerController.SourceType) {
        let controller = UIImagePickerController()
        controller.sourceType = type
        controller.delegate = self
        present(controller, animated: true, completion: nil)
    }
    
    /*
     Method name: processImage
     Description: This method handles the image request sent
     */
    func processImage() {
        //Clears all present text
        resultingText = ""
        guard let image = image else { return }
        
        textRecognitionWorkQueue.async {
            if let cgImage = image.cgImage {
                let requestHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
                do {
                    try requestHandler.perform(self.requests)
                } catch {
                    print(error)
                }
            }
            self.resultingText += "\n\n"
            
            DispatchQueue.main.async(execute: {
                billDetailsArray.append(self.resultingText)
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let controller = storyboard.instantiateViewController(withIdentifier: "ImageProcessedTableVC")
                self.navigationController?.pushViewController(controller, animated: true)
                self.hideUnhideControls(boolValue: false)
                self.loadingBillsLabel.text = "Loading Bills"
            })
        }
    }
    
    func hideUnhideControls(boolValue: Bool) {
        self.scanImageIcon.isHidden = boolValue
        self.scanImageLabel.isHidden = boolValue
        self.cameraImage.isHidden = boolValue
        self.choosePhotoButton.isHidden = boolValue
        self.activityIndicator.isHidden = !boolValue
        self.loadingBillsLabel.isHidden = !boolValue
    }
}

extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
        self.hideUnhideControls(boolValue: false)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        dismiss(animated: true, completion: nil)
        self.loadingBillsLabel.text = "Processing bill details"
        image = info[.originalImage] as? UIImage
        processImage()
    }
}


