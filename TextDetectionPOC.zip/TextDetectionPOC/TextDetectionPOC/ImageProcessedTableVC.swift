//
//  ImageProcessedTableVC.swift
//  TextDetectionPOC
//
//  Created by Sourav Purohit on 12/09/19.
//  Copyright © 2019 Pallavi Dash. All rights reserved.
//

import UIKit

class ImageProcessedTableVC: UIViewController,UITableViewDataSource {

    @IBOutlet weak var processedImageTableView: UITableView!
    var viewController = ViewController()
    override func viewDidLoad() {
        super.viewDidLoad()
        processedImageTableView.dataSource = self
        // Do any additional setup after loading the view.
        //self.processedImageTableView.register(TableViewCell.self, forCellReuseIdentifier: "cellClass")
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return billDetailsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellClass")!
        (cell.subviews[0].subviews[0] as? UILabel)?.text = billDetailsArray[indexPath.row]
        return cell
    }
}
